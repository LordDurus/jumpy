#![cfg(feature = "gba")]

use crate::platform::input::InputState;

pub fn poll() -> InputState {
	let input = InputState::default();
	return input;
}
