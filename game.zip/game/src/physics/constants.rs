pub const LEVEL_GRAVITY: f32 = 0.35;
pub const JUMP_VELOCITY: f32 = -8.0;
