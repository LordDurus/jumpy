pub const WORLD_GRAVITY: f32 = 0.35;
pub const JUMP_VELOCITY: f32 = -8.0;
pub const ENTITY_HALF_W: f32 = 7.0;
pub const ENTITY_HALF_HEIGHT: f32 = 7.0;
